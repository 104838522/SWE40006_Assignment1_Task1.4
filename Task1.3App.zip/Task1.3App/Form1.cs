﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using Task1._3ClassLibrary1; // ← DLL 네임스페이스

namespace Task1._3App
{
    public partial class Form1 : Form
    {
        public Form1()
        { 
            InitializeComponent();

            button1.Text = "Click Here!!!";
            button1.BackColor = System.Drawing.Color.LightBlue;
            button1.Font = new System.Drawing.Font("Arial", 12, System.Drawing.FontStyle.Bold);

            checkBox1.Text = "click";
            checkBox2.Text = "click";
            checkBox3.Text = "click";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "Task1.3 App";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is Task 1.3!\nI am \"Daehyeon Kim\"", "This is message");
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
            => checkBox1.Text = MyLib.Pick(checkBox1.Checked, "I");

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
            => checkBox2.Text = MyLib.Pick(checkBox2.Checked, "am");

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
            => checkBox3.Text = MyLib.Pick(checkBox3.Checked, "Daehyeon Kim");
    }
}
